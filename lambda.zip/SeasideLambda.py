import urllib.request
import urllib.parse
import json
from datetime import datetime, timezone, timedelta
from statistics import mean

def lambda_handler(event, context):
    print(f"DEBUG: 原始 event: {json.dumps(event)}")
    
    try:
        # 1. 解析 Payload (兼容 API Gateway 2.0)
        body_str = event.get("body", "{}")
        payload = json.loads(body_str) if isinstance(body_str, str) else body_str
        city = payload.get("city", "").strip()
        
        if not city:
            return {"statusCode": 400, "body": json.dumps({"error": "请提供城市名称"})}

        # 2. 地理编码：获取经纬度
        safe_city = urllib.parse.quote(city)
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={safe_city}&count=1"
        with urllib.request.urlopen(geo_url) as resp:
            geo_data = json.loads(resp.read().decode())
        
        if "results" not in geo_data:
            return {"statusCode": 400, "body": json.dumps({"error": f"找不到城市: {city}"})}
        
        location = geo_data["results"][0]
        lat, lon = location["latitude"], location["longitude"]
        official_name = location.get("name", city)

        # 3. 海水温度：获取过去 365 天的数据
        today = datetime.now(timezone.utc).date()
        start_date = (today - timedelta(days=365)).isoformat()
        end_date = today.isoformat()
        
        marine_url = (
            f"https://marine-api.open-meteo.com/v1/marine?"
            f"latitude={lat}&longitude={lon}&start_date={start_date}&end_date={end_date}"
            f"&daily=sea_surface_temperature_max,sea_surface_temperature_min&timezone=auto"
        )
        print(f"DEBUG: 请求海洋 API: {marine_url}")
        
        with urllib.request.urlopen(marine_url) as resp:
            marine_data = json.loads(resp.read().decode())
        
        if "daily" not in marine_data:
            return {"statusCode": 400, "body": json.dumps({"error": "该地点没有海水温度记录（可能不靠海）"})}

        # 4. 分析逻辑
        daily = marine_data["daily"]
        dates = daily["time"]
        max_ts = daily["sea_surface_temperature_max"]
        min_ts = daily["sea_surface_temperature_min"]
        
        ideal_periods = []
        start = None
        # 设置游泳门槛：21°C (地中海/欧洲标准)
        threshold = 21.0
        
        for i in range(len(dates)):
            if max_ts[i] is None or min_ts[i] is None: continue
            avg = (max_ts[i] + min_ts[i]) / 2
            if avg >= threshold:
                if start is None: start = dates[i]
                end = dates[i]
            else:
                if start is not None:
                    ideal_periods.append([start, end])
                    start = None
        if start is not None: ideal_periods.append([start, end])

        # 5. 格式化日期输出
        formatted_periods = []
        for s, e in ideal_periods:
            s_dt = datetime.strptime(s, "%Y-%m-%d")
            e_dt = datetime.strptime(e, "%Y-%m-%d")
            formatted_periods.append(f"{s_dt.strftime('%b %d')} - {e_dt.strftime('%b %d')}")

        # 6. 返回结果
        result = {
            "city": official_name,
            "country": location.get("country", ""),
            "avg_temp": round(mean([(h+l)/2 for h,l in zip(max_ts, min_ts) if h is not None]), 1),
            "ideal_periods": formatted_periods
        }

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps(result)
        }

    except Exception as e:
        print(f"ERROR: {str(e)}")
        return {"statusCode": 500, "body": json.dumps({"error": "服务器内部错误"})}