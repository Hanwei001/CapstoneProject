import urllib.request
import urllib.parse
import json
import boto3
from datetime import datetime, timezone, timedelta
from statistics import mean

# Initialize DynamoDB resource outside the handler for better performance
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('SeasideSearchHistory')

def lambda_handler(event, context):
    """
    Main handler for processing seaside vacation advisory requests.
    Fetches coordinates, analyzes marine temperatures, and stores history in DynamoDB.
    """
    print(f"DEBUG: Original event: {json.dumps(event)}")
    
    try:
        # 1. Parse Payload (Compatible with API Gateway 2.0 HTTP API)
        body_str = event.get("body", "{}")
        payload = json.loads(body_str) if isinstance(body_str, str) else body_str
        city = payload.get("city", "").strip()
        
        if not city:
            return {
                "statusCode": 400, 
                "body": json.dumps({"error": "Please provide a city name."})
            }

        # 2. Geocoding: Convert city name to coordinates
        safe_city = urllib.parse.quote(city)
        geo_url = f"https://geocoding-api.open-meteo.com/v1/search?name={safe_city}&count=1"
        
        with urllib.request.urlopen(geo_url) as resp:
            geo_data = json.loads(resp.read().decode())
        
        if "results" not in geo_data:
            return {
                "statusCode": 400, 
                "body": json.dumps({"error": f"City not found: {city}"})
            }
        
        location = geo_data["results"][0]
        lat, lon = location["latitude"], location["longitude"]
        official_name = location.get("name", city)

        # 3. Marine Data: Fetch sea surface temperature for the past 365 days
        today = datetime.now(timezone.utc).date()
        start_date = (today - timedelta(days=365)).isoformat()
        end_date = today.isoformat()
        
        marine_url = (
            f"https://marine-api.open-meteo.com/v1/marine?"
            f"latitude={lat}&longitude={lon}&start_date={start_date}&end_date={end_date}"
            f"&daily=sea_surface_temperature_max,sea_surface_temperature_min&timezone=auto"
        )
        print(f"DEBUG: Requesting Marine API: {marine_url}")
        
        with urllib.request.urlopen(marine_url) as resp:
            marine_data = json.loads(resp.read().decode())
        
        if "daily" not in marine_data:
            return {
                "statusCode": 400, 
                "body": json.dumps({"error": "No marine data available for this location."})
            }

        # 4. Analysis Logic: Filter periods meeting the temperature threshold
        daily = marine_data["daily"]
        dates = daily["time"]
        max_ts = daily["sea_surface_temperature_max"]
        min_ts = daily["sea_surface_temperature_min"]
        
        ideal_periods = []
        start = None
        # Threshold for comfortable swimming: 21°C
        threshold = 21.0
        
        for i in range(len(dates)):
            if max_ts[i] is None or min_ts[i] is None: 
                continue
            avg = (max_ts[i] + min_ts[i]) / 2
            if avg >= threshold:
                if start is None: 
                    start = dates[i]
                end = dates[i]
            else:
                if start is not None:
                    ideal_periods.append([start, end])
                    start = None
        if start is not None: 
            ideal_periods.append([start, end])

        # 5. Format Output Dates
        formatted_periods = []
        for s, e in ideal_periods:
            s_dt = datetime.strptime(s, "%Y-%m-%d")
            e_dt = datetime.strptime(e, "%Y-%m-%d")
            formatted_periods.append(f"{s_dt.strftime('%b %d')} - {e_dt.strftime('%b %d')}")

        # 6. Prepare Final Result
        # Calculate daily average for the chart
        daily_averages = []
        for h, l in zip(max_ts, min_ts):
            if h is not None and l is not None:
                daily_averages.append(round((h + l) / 2, 1))
            else:
                daily_averages.append(None)

        result = {
            "city": official_name,
            "country": location.get("country", ""),
            "avg_temp": round(mean([avg for avg in daily_averages if avg is not None]), 1),
            "ideal_periods": formatted_periods,
            "chart_data": { 
                "labels": dates,      
                "values": daily_averages 
            }
        }

        # 7. Persistence: Save search history to DynamoDB
        try:
            db_item = {
                "City": result["city"],
                "Timestamp": datetime.now(timezone.utc).isoformat(),
                "Country": result["country"],
                "AvgTemp": str(result["avg_temp"]), # Saved as string for precision
                "IdealPeriods": result["ideal_periods"]
            }
            table.put_item(Item=db_item)
            print(f"DEBUG: Successfully saved history for {official_name}")
        except Exception as db_err:
            # We log the error but don't fail the request if DB write fails
            print(f"DATABASE ERROR: {str(db_err)}")

        # 8. Return Response to Client
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            "body": json.dumps(result)
        }

    except Exception as e:
        print(f"CRITICAL ERROR: {str(e)}")
        return {
            "statusCode": 500, 
            "body": json.dumps({"error": "Internal Server Error"})
        }